// =====================================================================
//  LA REDSTONE QUI RESTAIT — CE QUI NE DEPEND D'AUCUN MOD
//
//  00_redstone.zs coupait les OBJETS de redstone (piston, repeteur,
//  plaque, entonnoir...). Il ne disait rien des recettes qui, ailleurs
//  dans le pack, demandent encore un grain de poudre pour fabriquer
//  autre chose. Elles etaient toujours la, et l'une d'elles bloquait le
//  serveur : BetterWithMods avait remplace la recette du LEVIER par une
//  recette qui exige de la poudre — or le levier est justement la seule
//  piece de redstone qu'on ait volontairement gardee, celle que le
//  souffletier actionne.
//
//  Ce fichier et son voisin 17_redstone_des_mods.zs sont le resultat
//  d'un balayage de TOUS les jars du pack : chaque fichier
//  assets/<mod>/recipes/**.json a ete lu, plus les recettes ecrites en
//  dur dans le bytecode (Rustic, et HCOres de BetterWithMods pour la
//  boussole). Ensemble, ils couvrent tout ce qui demandait encore de la
//  redstone et qui restait atteignable.
//
//  ⚠ Pourquoi DEUX fichiers : celui-ci ne nomme que des objets vanilla,
//  il ne peut donc pas echouer. Le second nomme des objets de six mods,
//  et un script qui nomme un objet absent ne se charge pas DU TOUT — la
//  correction la plus importante des deux (le levier) ne doit pas
//  pouvoir tomber avec lui.
//
//  Apres modification : REDEMARRAGE COMPLET.
// =====================================================================


// ---------------------------------------------------------------------
//  1. LE LEVIER — la correction la plus importante des deux fichiers
//
//  Recette d'origine de BetterWithMods (assets/betterwithmods/recipes/
//  hcredstone/lever.json, active parce que hardcore.HCRedstone=true
//  dans config/betterwithmods.cfg) :
//
//      S        S = baton
//      C        C = pierre taillee
//      R        R = poudre de redstone
//
//  Elle remplace la recette vanilla, qui ne demandait qu'un baton et de
//  la pierre. Sans levier fabricable, le poste de souffletier n'a rien
//  a actionner et tout le feu alimente tombe — c'est-a-dire le creuset,
//  le savon, la colle et la potasse.
//
//  On rend donc la recette d'origine : un manche de bois sur un socle
//  de pierre. Rien de plus, parce que rien de plus n'est justifie —
//  l'exception du levier a ete decidee pour qu'un homme puisse
//  actionner un soufflet, pas pour en faire un objet rare.
// ---------------------------------------------------------------------

recipes.remove(<minecraft:lever>);

recipes.addShaped("medievalcore_levier", <minecraft:lever>, [
    [<ore:stickWood>],
    [<ore:cobblestone>]
]);


// ---------------------------------------------------------------------
//  2. LA BOUSSOLE — 02_anachronismes.zs la garde volontairement
//
//  Elle a deux recettes selon les mods charges, et c'est BetterWithMods
//  qui gagne : HCOres (« Fix Vanilla Recipes ») remplace la recette
//  vanilla par quatre pepites de fer autour d'un grain de poudre —
//  verifie au bytecode de
//  betterwithmods.module.hardcore.crafting.HCOres.init().
//
//  Les deux recettes sortent ici par le meme recipes.remove : il porte
//  sur l'OBJET produit, pas sur une recette en particulier.
//
//  L'aiguille aimantee du XIVe siecle est un fil de fer frotte a la
//  magnetite, monte sur un pivot. On garde donc les quatre pepites de
//  fer du boitier et l'on met une pepite d'OR au centre : le pivot, la
//  seule piece qui doit tourner sans rouiller.
// ---------------------------------------------------------------------

recipes.remove(<minecraft:compass>);

recipes.addShaped("medievalcore_boussole", <minecraft:compass>, [
    [null,              <ore:nuggetIron>, null],
    [<ore:nuggetIron>,  <ore:nuggetGold>, <ore:nuggetIron>],
    [null,              <ore:nuggetIron>, null]
]);
