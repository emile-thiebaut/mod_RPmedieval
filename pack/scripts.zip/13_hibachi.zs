#modloaded betterwithmods

// =====================================================================
//  L'HIBACHI : SORTIR LA RECETTE DU NETHER
//
//  Recette d'origine (assets/betterwithmods/recipes/blocks/redstone/
//  hibachi.json, lue telle quelle dans le jar) :
//
//      HHH        H = betterwithmods:material:17 (feu de l'enfer concentre)
//      SES        S = pierre
//      SRS        E = betterwithmods:material:27 (l'ELEMENT chauffant)
//                 R = poudre de redstone
//
//  Deux ingredients bloquent ce serveur, qui n'a pas de Nether :
//
//    * le FEU DE L'ENFER CONCENTRE se prepare en cuisant de la poudre de
//      feu de l'enfer dans un chaudron non attise (verifie au bytecode
//      de CauldronRecipes.unstoked(), la sortie porte bien
//      EnumMaterial.CONCENTRATED_HELLFIRE). Cette poudre elle-meme vient
//      du netherrack broyé, filtre a travers un entonnoir filtre avec un
//      tamis de sable des ames — deux etages qui remontent tous les deux
//      jusqu'au netherrack ;
//
//    * l'ELEMENT CHAUFFANT se prepare dans le meme genre de chaudron a
//      partir d'un fil (corde ou fibre de chanvre), de POUDRE DE BLAZE et
//      de poudre de redstone (verifie au meme endroit : l'appel prend
//      dustBlaze et dustRedstone). La poudre de blaze n'existe que dans
//      le Nether.
//
//  On remplace les deux par du charbon de bois et du fer : un brasero de
//  forge, pas un objet d'alchimie.
//
//  ⚠ LA POUDRE DE REDSTONE EST PARTIE ELLE AUSSI, et c'est un
//  changement du 20 aout 2026. La premiere version la gardait en
//  disant : c'est le signal de redstone qui fait bruler l'hibachi
//  (« The Hibachi will create a continuous fire source when given a
//  Redstone Signal », manuel du mod), donc il en faut un peu des la
//  fabrication. L'argument ne tient pas : ce qui allume l'hibachi, c'est
//  le SIGNAL, et le signal vient du LEVIER. Il n'y a aucune poudre dans
//  un levier, et il n'y en a plus dans un hibachi.
//
//  A la place, le troisieme ingredient est de l'OBSIDIENNE : une pierre
//  qui ne fond pas, ce qu'on veut precisement sous un feu qui ne
//  s'eteint jamais. Elle est difficile a obtenir — il faut une pioche
//  de diamant, donc des diamants, donc de la mine profonde — et c'est
//  voulu : le feu alimente ouvre le creuset, le savon, la colle et la
//  potasse, il ne doit pas s'acheter au premier soir.
//
//  Ce qui n'est PAS gate au passage : l'obsidienne ne demande rien qui
//  demande deja un feu alimente. Le contraire aurait ferme la chaine
//  sur elle-meme, comme l'aurait fait un ingredient en acier forge
//  d'ame — verifie avant de choisir.
//
//  Apres modification : REDEMARRAGE COMPLET.
// =====================================================================

recipes.remove(<betterwithmods:hibachi>);

recipes.addShaped(<betterwithmods:hibachi>, [
    [<minecraft:coal:1>,   <minecraft:coal:1>,    <minecraft:coal:1>],
    [<ore:stone>,          <ore:ingotIron>,       <ore:stone>],
    [<ore:stone>,          <minecraft:obsidian>,  <ore:stone>]
]);
