// =====================================================================
//  LA MEDECINE : RACCROCHER FIRST AID AU RESTE DU PACK
//
//  First Aid decoupe la sante en membres et demande du materiel pour les
//  soigner. Ses trois recettes d'origine ne tiennent pas sur ce serveur :
//
//    * le BANDAGE se fait avec de la laine et de la ficelle. C'est
//      juste, mais c'est aussi gratuit : on en a un coffre au premier
//      troupeau, et le systeme de blessures cesse d'exister ;
//
//    * le PLATRE, pareil, en plus petit ;
//
//    * la MORPHINE se fait avec DEUX YEUX D'ARAIGNEE FERMENTES. Il faut
//      donc une verrue du Nether pour les fermenter — et ce serveur n'a
//      pas de Nether (voir 01_magie_et_autres_mondes.zs). La recette
//      d'origine est purement et simplement INFAISABLE ici.
//
//  On les refait donc toutes les trois en passant par ce que le pack
//  cultive vraiment : le chanvre de BetterWithMods, les simples de
//  Rustic, la cire de ses ruches.
//
//  IDENTIFIANTS — tous verifies, aucun devine :
//    * firstaid:bandage / plaster / morphine  <- recettes du jar
//    * betterwithmods:material:4 = toile de chanvre  <- ordinal de
//      ItemMaterial$EnumMaterial, dont getMetadata() rend ordinal()
//    * le domaine de BetterWithMods est « betterwithmods », PAS « bwm » :
//      le prefixe bwm: des fichiers .lang n'est pas un domaine de
//      registre, les recettes du jar disent betterwithmods:cooking_pot
//    * rustic:aloe_vera / horsetail / chamomile / deathstalk_mushroom
//      <- blockstates/ du jar, la seule source qui fasse foi pour un bloc
//    * rustic:beeswax  <- constantes de rustic.common.items.ModItems
//
//  ON N'INTRODUIT AUCUN OBJET INTERMEDIAIRE. La premiere version passait
//  par un « linge propre » represente par du parchemin — jusqu'a ce
//  qu'on remarque que le parchemin vaut 3 deniers au catalogue des
//  marchands. Fabriquer du linge avec de la laine serait devenu une
//  presse a monnaie. Les chaines courtes n'ont pas ce defaut.
//
//  Apres modification : REDEMARRAGE COMPLET. Les suppressions de
//  recettes ne se rechargent pas a chaud.
// =====================================================================

import crafttweaker.item.IItemStack;
import crafttweaker.item.IIngredient;


// ---------------------------------------------------------------------
//  On efface les trois recettes d'origine
// ---------------------------------------------------------------------

recipes.remove(<firstaid:bandage>);
recipes.remove(<firstaid:plaster>);
recipes.remove(<firstaid:morphine>);


// ---------------------------------------------------------------------
//  1. LE BANDAGE — de la toile, et de quoi calmer la plaie
//
//  Deux voies, et l'ecart entre elles est tout l'interet :
//
//    * la TOILE DE CHANVRE de BetterWithMods pour qui a monte la
//      corderie — chanvre seme, fibres battues, toile tissee. Trois
//      pieces par craft ;
//
//    * la LAINE pour qui n'a que des moutons. Une seule piece, et il y
//      faut de la ficelle en plus.
//
//  On ne ferme pas la porte au debutant, on rend l'autre chemin
//  nettement meilleur. C'est la meme regle que partout ailleurs sur ce
//  serveur : rien n'est interdit, tout est plus cher quand on n'a rien
//  bati.
//
//  L'aloes est l'ingredient juste : c'est LE cicatrisant que le pack
//  fait pousser, et Rustic le place dans les biomes secs — savane, mesa,
//  sable — donc loin des villages de plaine. Il faut aller le chercher,
//  ou apprendre a le cultiver.
// ---------------------------------------------------------------------

recipes.addShapeless("medieval_bandage_chanvre", <firstaid:bandage> * 3,
    [<betterwithmods:material:4>, <rustic:aloe_vera>]);

recipes.addShapeless("medieval_bandage_laine", <firstaid:bandage>,
    [<ore:wool>, <ore:string>, <ore:string>, <rustic:aloe_vera>]);


// ---------------------------------------------------------------------
//  2. LE PLATRE — un bandage, plus de quoi le faire prendre
//
//  Un membre casse s'immobilise : il faut du liant. L'argile est le
//  liant du pauvre ; la prele (horsetail) est ce que les rebouteux
//  employaient vraiment — elle est chargee de silice, et Rustic la fait
//  pousser en marais et en foret.
//
//  Il passe par le bandage, donc par l'aloes : c'est la seule chaine a
//  deux etages du lot, et c'est normal — un platre est un bandage qu'on
//  a rendu rigide, pas un objet different.
// ---------------------------------------------------------------------

recipes.addShapeless("medieval_platre", <firstaid:plaster> * 2,
    [<firstaid:bandage>, <minecraft:clay_ball>, <minecraft:clay_ball>,
     <rustic:horsetail>]);


// ---------------------------------------------------------------------
//  3. LA MORPHINE — l'apothicaire, pas le Nether
//
//  Elle fait taire les malus des membres blesses. C'est un produit
//  d'apothicaire, donc elle passe par l'apothicairerie : la camomille
//  calme, le champignon deathstalk de Rustic est le poison qui, dose,
//  devient l'anesthesique. La cire bouche la fiole.
//
//  C'est volontairement la plus chere du lot. La morphine ne SOIGNE
//  rien : elle permet de continuer a se battre en etant blesse. Une
//  chose pareille doit se payer, sinon elle remplace les soins.
//
//  Rappel — un ELIXIR DE RUSTIC, bu, fait deja le meme effet, et leve la
//  peste par-dessus le marche. C'est MedievalCore qui le branche
//  (village/GestionnaireRemedes.java), pas ce script. Cette recette-ci
//  est la voie courte, pour qui n'a pas monte de condenseur.
// ---------------------------------------------------------------------

recipes.addShaped("medieval_morphine", <firstaid:morphine>,
   [[<rustic:chamomile>,       <rustic:deathstalk_mushroom>, <rustic:chamomile>],
    [<minecraft:glass_bottle>, <rustic:beeswax>,             <minecraft:glass_bottle>]]);


// ---------------------------------------------------------------------
//  4. CE QU'ON NE TOUCHE PAS
//
//  Les elixirs de Rustic gardent leurs recettes de condenseur. Ils sont
//  deja a la bonne difficulte — condenseur, alambics, combustible,
//  simples cultives — et c'est justement ce qui fait d'eux la
//  recompense de celui qui se passe de guerisseur.
//
//  On ne touche pas non plus a la sangsue de peste ni au liquide de
//  purification de Rats : ils restent les remedes du mod d'origine, pour
//  qui les trouve.
// ---------------------------------------------------------------------
