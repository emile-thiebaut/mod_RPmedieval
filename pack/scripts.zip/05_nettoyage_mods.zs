// =====================================================================
//  ELAGAGE DES MODS
//
//  Ce que les configurations ne permettent pas de couper, on le retire
//  ici : recettes supprimees et objets masques de JEI.
// =====================================================================

import crafttweaker.item.IItemStack;
import mods.jei.JEI;

// --- Just A Few Fish : une seule canne ------------------------------
// La canne en bois suffit. Les cannes en fer, en or et en diamant sont
// des paliers de progression tires du jeu moderne, sans rapport avec la
// peche medievale.
val cannes = [
    <jaff:iron_fishing_rod>,
    <jaff:golden_fishing_rod>,
    <jaff:diamond_fishing_rod>
] as IItemStack[];

for canne in cannes {
    JEI.removeAndHide(canne);
}

// --- Familiar Fauna : plus de fees ----------------------------------
// Leur apparition est coupee dans config/familiarfauna/config.cfg.
// Reste la poussiere de fee, qui n'a plus d'objet.
//
// Le bocal a insectes ne se touche PAS : il n'existe qu'UN seul objet,
// <familiarfauna:bug_habitat> (verifie au javap dans familiarfauna.api
// .FFItems). Les fichiers bug_habitat_blue_pixie et compagnie sont des
// MODELES choisis d'apres le NBT de la bete capturee, pas des objets.
// Le masquer priverait aussi des papillons et des libellules, alors que
// le bocal a fee est de toute facon inobtenable sans fees.
JEI.removeAndHide(<familiarfauna:pixie_dust>);

// --- Serene Seasons : ni serre ni capteur ---------------------------
// La hauteur de verre de serre est deja a zero dans cropfertility.cfg,
// mais le bloc restait fabricable. Le capteur de saison, lui, est un
// composant de redstone.
//
// Le capteur n'est pas un bloc unique : Serene Seasons en enregistre
// QUATRE, un par saison (assets/sereneseasons/blockstates/). Seul celui
// du printemps se fabrique, les autres s'obtiennent en cliquant dessus,
// mais ils existent tous les quatre et se masquent separement.
val sereneSeasons = [
    <sereneseasons:greenhouse_glass>,
    <sereneseasons:season_sensor_spring>,
    <sereneseasons:season_sensor_summer>,
    <sereneseasons:season_sensor_autumn>,
    <sereneseasons:season_sensor_winter>
] as IItemStack[];

for objet in sereneSeasons {
    JEI.removeAndHide(objet);
}

// --- Tough As Nails : ce qui n'est pas d'epoque ---------------------
// Les bobines de chauffage et de refroidissement sont remplacees par
// l'atre de Dawn of Time et la pierre calcaire, reglees dans
// config/toughasnails/block_temperature.json.
val toughAsNails = [
    <toughasnails:temperature_coil:0>,
    <toughasnails:temperature_coil:1>,
    <toughasnails:jelled_slime>,
    <toughasnails:jelled_slime_helmet>,
    <toughasnails:jelled_slime_chestplate>,
    <toughasnails:jelled_slime_leggings>,
    <toughasnails:jelled_slime_boots>
] as IItemStack[];

for objet in toughAsNails {
    JEI.removeAndHide(objet);
}

// Les jus de Tough As Nails font doublon avec ceux de Rustic, qui sont
// bien plus interessants : ils passent par le pressoir et le tonneau.
//
// Les dix jus ne sont pas dix objets mais UN SEUL, <toughasnails:
// fruit_juice>, decline par metadonnee. L'ordre des metadonnees est
// celui de l'enumeration ItemFruitJuice$JuiceType, lue au javap.
val jus = [
    <toughasnails:fruit_juice:0>,  // pomme
    <toughasnails:fruit_juice:1>,  // betterave
    <toughasnails:fruit_juice:2>,  // cactus
    <toughasnails:fruit_juice:3>,  // carotte
    <toughasnails:fruit_juice:4>,  // fruit du chorus
    <toughasnails:fruit_juice:5>,  // melon scintillant
    <toughasnails:fruit_juice:6>,  // pomme d'or
    <toughasnails:fruit_juice:7>,  // carotte doree
    <toughasnails:fruit_juice:8>,  // melon
    <toughasnails:fruit_juice:9>   // citrouille
] as IItemStack[];

for boisson in jus {
    JEI.removeAndHide(boisson);
}

// --- Dawn of Time -----------------------------------------------------
// Le calcaire pave et la cire sont traites dans 18_dawn_of_time.zs :
// leurs recettes ne sont pas masquees mais REFAITES, et ce fichier-ci ne
// doit pas dependre de la presence de Dawn of Time.
