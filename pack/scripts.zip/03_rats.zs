// =====================================================================
//  RATS : NE GARDER QUE LE NUISIBLE
//  La config (config/rats.cfg) a deja coupe Ratlantis, le plastique et
//  le joueur de flute. Ici on retire tout ce qui reste craftable :
//  cages, ameliorations, golems, jetons. Il ne doit subsister que le rat
//  sauvage qui pille les coffres et les cultures.
// =====================================================================

import crafttweaker.item.IItemStack;
import mods.jei.JEI;

// loadedMods[...].items renvoie directement des IItemStack : pas de
// makeStack() a appeler dessus.
if (loadedMods has "rats") {
    for objet in loadedMods["rats"].items {
        JEI.removeAndHide(objet);
    }
}

// Le fromage de Rats ferait doublon avec Animania et Growthcraft, qui le
// produisent de maniere bien plus interessante (lait de qualite, affinage
// en tonneau). Il disparait donc avec le reste.
