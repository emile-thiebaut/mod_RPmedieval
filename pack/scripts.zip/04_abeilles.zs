// =====================================================================
//  UN SEUL SYSTEME D'ABEILLES : CELUI D'ANIMANIA
//
//  Rustic et Animania apportent chacun ses abeilles, ses ruches et son
//  miel. On garde Animania, dont les abeilles sont de vraies betes qu'on
//  eleve, et on retire celles de Rustic.
//
//  Raison de fond en plus du doublon : les abeilles de Rustic FERTILISENT
//  les cultures dans un rayon de quatre blocs. C'est un accelerateur de
//  croissance, exactement ce qu'on cherche a eviter dans une agriculture
//  qui doit rester lente et saisonniere.
//
//  La generation des ruches sauvages de Rustic est coupee separement,
//  dans config/rustic.cfg (Beehive Generation Chance = 0).
// =====================================================================

import crafttweaker.item.IItemStack;
import mods.jei.JEI;

val abeillesRustic = [
    <rustic:apiary>,     // la ruche d'elevage
    <rustic:beehive>,    // la ruche sauvage des arbres
    <rustic:bee>         // l'abeille elle-meme
] as IItemStack[];

for objet in abeillesRustic {
    JEI.removeAndHide(objet);
}

// --- La passerelle : le miel d'Animania nourrit Rustic ---------------
//
// La cire, le rayon de miel et le miel de Rustic restent dans le jeu,
// parce que les BOUGIES, l'alchimie et l'hydromel en dependent. Sans
// apiaire ni ruche sauvage ils seraient devenus introuvables.
//
// On les rebranche donc sur la seule source de miel qui reste, la ruche
// d'Animania : TROIS fioles alignees donnent six rayons.
//
// Pourquoi trois d'un coup, et pas une : le miel d'Animania sert deja a
// faire du sucre. S'il suffisait d'une fiole, le joueur arbitrerait fiole
// par fiole sans y penser. A trois, l'egouttage devient un geste decide —
// on vide un plein casier de fioles pour approvisionner le chandelier.
//
// Identifiants verifies au javap, jamais devines :
//   com.animania.common.items.AnimaniaItem  ->  registre "animania:<nom>",
//   nom non localise "animania_<nom>". Le fichier .lang dit
//   "animania_honey_bottle", donc l'objet est bien <animania:honey_bottle>.
//   Cote Rustic, rustic.common.items.ModItems.HONEYCOMB -> rustic:honeycomb.
//
// Les fioles vides reviennent toutes seules : ItemHoneyBottle declare la
// bouteille de verre comme objet conteneur (hasContainerItem = true,
// getContainerItem = Items.GLASS_BOTTLE), et CraftTweaker rend le conteneur
// des ingredients sans transformateur — MCRecipeShaped.getRemainingItems
// retombe sur ForgeHooks.getContainerItem. Inutile d'ecrire un
// transformReplace.
//
// Recette faconnee : les trois fioles doivent etre cote a cote sur une
// meme ligne. C'est le geste de l'egouttage, pas un melange.
//
// 18/09/2026, a la demande du proprietaire : UNE fiole suffit, et elle
// donne trois rayons. Le geste « decide » des trois fioles alignees
// rendait la cire -- donc le bois cire et les bougies -- trop chere pour
// batir.
//
// Un BATON avec la fiole, et ce n'est pas un ornement : Animania fait deja
// huit sucres d'une fiole seule (assets/farm/animania/recipes/sugar.json,
// sans forme). Une seconde recette « une fiole seule » aurait ete en
// conflit -- l'etabli n'en montre qu'une, et l'on ne sait jamais laquelle.
// Le baton, c'est le cadre ou l'on coule le rayon.
recipes.addShapeless("miel_animania_vers_rayon",
    <rustic:honeycomb> * 3,
    [<animania:honey_bottle>, <ore:stickWood>]);

// La fiole de miel porte une etiquette NBT (1000 mB de fluide honey), mais
// un ingredient CraftTweaker sans etiquette accepte n'importe quelle NBT :
// MCItemStack.matches ne compare les NBT que si l'ingredient en a une.
// La recette accepte donc aussi bien la fiole de la ruche que celle du
// mode creatif.
//
// Pas de boucle possible : le miel liquide de Rustic obtenu en ecrasant le
// rayon ne redonne jamais de fiole d'Animania.

// --- La cire de Dawn of Time ----------------------------------------
//
// Elle faisait doublon avec <rustic:beeswax>, et pour dix fois moins
// cher (un sucre + une torche). Elle est retiree, et les planches
// cirees refaites a la cire d'abeille, dans 18_dawn_of_time.zs — pas
// ici, parce que nommer un objet de Dawn of Time dans ce fichier le
// ferait tomber en entier le jour ou le mod partirait.
