#modloaded dawnoftimebuilder rustic

// =====================================================================
//  DAWN OF TIME : LA CIRE ET LE CALCAIRE
//
//  Deux recettes de Dawn of Time genaient le pack. Elles sont refaites
//  ici plutot que dans 04_abeilles.zs et 05_nettoyage_mods.zs : ce
//  fichier nomme des objets de DEUX mods, et un script qui nomme un
//  objet absent ne se charge pas DU TOUT. Le mettre a part garde intacts
//  les deux autres le jour ou l'un des mods quitte le pack — c'est la
//  meme regle que pour 16/17_redstone.
//
//  Apres modification : REDEMARRAGE COMPLET.
// =====================================================================

import mods.jei.JEI;


// ---------------------------------------------------------------------
//  1. UNE SEULE CIRE : CELLE DE RUSTIC
//
//  Recette d'origine (assets/dawnoftimebuilder/recipes/wax.json, lue
//  telle quelle dans le jar) : UN SUCRE + UNE TORCHE, sans forme, pour
//  DIX cires. C'est un doublon de <rustic:beeswax> — la vraie cire, qui
//  vient du rayon de miel fondu au four, donc de la ruche d'Animania par
//  la passerelle de 04_abeilles.zs.
//
//  Et c'est le doublon le moins cher des deux : dix cires pour une
//  torche court-circuitait toute la chaine apicole. On retire l'objet.
//
//  Il ne servait qu'aux planches cirees (verifie : seuls
//  oak_waxed_planks.json et waxed_oak_planks.json le nomment). On les
//  refait donc a la cire d'abeille, et le reste de la gamme — dalle,
//  bordure, escalier, barriere — repart d'elles sans y toucher.
// ---------------------------------------------------------------------

JEI.removeAndHide(<dawnoftimebuilder:wax>);

// Les DEUX recettes d'origine partent d'un coup : le jar en porte une de
// 2x2 (oak_waxed_planks.json) et une de 1x2 (waxed_oak_planks.json), et
// recipes.remove ne regarde que la sortie.
recipes.remove(<dawnoftimebuilder:oak_waxed_planks>);

// Une cire en diagonale sur deux planches : le geste de l'enduit, et la
// meme grille que celle du mod pour ne pas depayser.
recipes.addShaped("medievalcore_planches_cirees",
    <dawnoftimebuilder:oak_waxed_planks> * 6, [
    [<rustic:beeswax>, <minecraft:planks:0>],
    [<minecraft:planks:0>, <rustic:beeswax>]
]);


// ---------------------------------------------------------------------
//  2. LE CALCAIRE, QUI PRENAIT LA PLACE DE LA TAILLE DE PIERRE
//
//  Recette d'origine (cobbled_limestone.json) : QUATRE PAVES en carre,
//  pour quatre calcaires. Une grille de 2x2 en pave nu est la forme la
//  plus banale qui soit — c'est le geste qu'on fait sans y penser en
//  taillant la pierre, et il rendait du calcaire de Dawn of Time a la
//  place de ce qu'on visait.
//
//  On la retire et on en donne une qui se DECIDE : quatre paves autour
//  d'une poignee de sable. Le sable est le liant, ce qui est d'ailleurs
//  a peu pres vrai d'un mortier de chaux, et surtout la grille en croix
//  n'est plus quelque chose qu'on compose par accident.
// ---------------------------------------------------------------------

recipes.remove(<dawnoftimebuilder:cobbled_limestone>);

recipes.addShaped("medievalcore_calcaire",
    <dawnoftimebuilder:cobbled_limestone> * 4, [
    [null,               <ore:cobblestone>, null],
    [<ore:cobblestone>,  <ore:sand>,        <ore:cobblestone>],
    [null,               <ore:cobblestone>, null]
]);
