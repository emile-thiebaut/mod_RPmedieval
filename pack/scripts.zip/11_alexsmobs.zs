#modloaded alexsmobs

// =====================================================================
//  CE SCRIPT NE S'EXECUTE QUE SI ALEX'S MOBS EST CHARGE
//
//  Meme regle que 09_oiseaux.zs : un script qui nomme un mod pouvant
//  manquer d'un cote (l'instance l'a, le serveur pourrait ne pas l'avoir
//  encore) porte un « #modloaded » en tete. Sans lui, le premier objet
//  introuvable fait MOURIR le script entier, en silence, et tout ce qui
//  suit ne se pose jamais. Les 43 noms ci-dessous ont ete verifies un a
//  un contre assets/alexsmobs/models/item/ — la seule source fiable des
//  noms de registre (le .lang ment parfois sur l'ordre, jamais le modele).
// =====================================================================

// =====================================================================
//  ALEX'S MOBS : GARDER LES BETES REELLES, COUPER LEURS OBJETS HORS SUJET
//
//  Le filtre du serveur pour ce mod est « animaux reels de la Terre » :
//  l'elephant, le gorille, le tigre, le crocodile restent. Ce sont donc
//  les APPARITIONS des betes imaginaires qui tombent (a spawnWeight=0
//  dans alexsmobs.cfg), pas leurs recettes.
//
//  Mais desactiver une apparition ne fait pas disparaitre les OBJETS que
//  le mod enregistre malgre tout. Ils restent fabricables, visibles dans
//  JEI, obtenables au triche. CraftTweaker touche justement aux recettes
//  et a JEI : c'est ici qu'on coupe.
//
//  Quatre familles d'objets ne passent pas le filtre. Le reste — fourrure,
//  corne, cuir, viande, dents, plumes, seaux de vrais poissons, venins de
//  betes reelles — n'est PAS touche : c'est le produit d'un animal, donc
//  une marchandise ou une nourriture legitime.
//
//  Apres modification : REDEMARRAGE COMPLET (les scripts ne se rechargent
//  pas a chaud).
// =====================================================================

import crafttweaker.item.IItemStack;
import mods.jei.JEI;


// ---------------------------------------------------------------------
//  1. LES OBJETS D'UN AUTRE MONDE
//
//  End, Nether, Void, creatures « warped » : exactement ce que
//  01_magie_et_autres_mondes.zs bannit partout ailleurs. Les betes sont
//  deja eteintes ; on efface la trace qu'elles laissaient a l'etabli.
// ---------------------------------------------------------------------

val autresMondes = [
    <alexsmobs:bone_serpent_tooth>,   // serpent d'os (Nether)
    <alexsmobs:halo>,                 // aureole (spectre)
    <alexsmobs:soul_heart>,           // coeur d'ame (vautour des ames)
    <alexsmobs:blood_sac>,            // moustique cramoisi (Nether)
    <alexsmobs:mosquito_proboscis>,
    <alexsmobs:mosquito_larva>,
    <alexsmobs:chorus_on_a_stick>,    // fruit du chorus (End)
    <alexsmobs:guster_eye>,           // guster (elementaire)
    <alexsmobs:pocket_sand>,
    <alexsmobs:warped_muscle>,        // crapaud/mosco warped (Nether)
    <alexsmobs:warped_mixture>,
    <alexsmobs:hemolymph_sac>,
    <alexsmobs:enderiophage_rocket>,  // enderiophage (End)
    <alexsmobs:endolocator>,
    <alexsmobs:mysterious_worm>,      // ver du vide (End, invocation de boss)
    <alexsmobs:void_worm_mandible>,
    <alexsmobs:void_worm_eye>,
    <alexsmobs:dimensional_carver>,   // creuse un portail dimensionnel
    <alexsmobs:mimicream>,            // duplique les objets (mimicube, End)
    <alexsmobs:cosmic_cod>,           // morue cosmique (End)
    <alexsmobs:cosmic_cod_bucket>,
    <alexsmobs:straddlite>,           // straddler (End)
    <alexsmobs:stradpole_bucket>,
    <alexsmobs:squid_grapple>,        // calmar geant (ecarte comme kraken)
    <alexsmobs:lost_tentacle>
] as IItemStack[];

for objet in autresMondes {
    JEI.removeAndHide(objet);
}


// ---------------------------------------------------------------------
//  2. LES ARMES A FEU
//
//  Des engins qui pulverisent un projectile a distance. Il n'y a pas de
//  poudre sur ce serveur, et encore moins de canon de poing.
// ---------------------------------------------------------------------

val armesAFeu = [
    <alexsmobs:blood_sprayer>,        // pulverise le sang du moustique
    <alexsmobs:hemolymph_blaster>,    // canon a hemolymphe
    <alexsmobs:stink_ray>             // pistolet a puanteur du sconse
] as IItemStack[];

for objet in armesAFeu {
    JEI.removeAndHide(objet);
}


// ---------------------------------------------------------------------
//  3. LE VOL, LA GRIMPE, LES EFFETS MAGIQUES
//
//  Un paysan ne plane pas, ne court pas sur le sable comme un demon, ne
//  grimpe pas aux murs. Ces pieces donnent des pouvoirs que le pack
//  refuse au meme titre que la redstone.
//
//  Les betes, elles, restent : c'est l'objet enchante qui saute, pas
//  l'emeu ni le bihoreau. Leurs plumes, oeufs et cuirs sont intacts.
// ---------------------------------------------------------------------

val objetsMagiques = [
    <alexsmobs:tarantula_hawk_elytra>,  // ailes de vol (elytra)
    <alexsmobs:straddleboard>,          // planche volante (End)
    <alexsmobs:straddle_helmet>,
    <alexsmobs:straddle_saddle>,
    <alexsmobs:roadrunner_boots>,       // +vitesse sur le sable
    <alexsmobs:pigshoes>,               // « fers » anciens, +vitesse
    <alexsmobs:centipede_leggings>,     // grimpe aux murs
    <alexsmobs:emu_leggings>,           // esquive les projectiles
    <alexsmobs:echolocator>,            // sonar du cachalot
    <alexsmobs:lava_bottle>             // deja coupe en config, on masque
] as IItemStack[];

for objet in objetsMagiques {
    JEI.removeAndHide(objet);
}


// ---------------------------------------------------------------------
//  4. LES ANACHRONISMES CULTURELS
//
//  Un sombrero, un fedora, un disque de musique : des objets d'un autre
//  siecle ou d'un autre continent, qui brisent l'image au premier coup
//  d'oeil. La coiffe de trappeur (frontier cap) est du meme registre —
//  le trappeur nord-americain n'existera pas avant trois cents ans.
// ---------------------------------------------------------------------

val anachronismes = [
    <alexsmobs:sombrero>,
    <alexsmobs:fedora>,
    <alexsmobs:frontier_cap>,
    <alexsmobs:music_disc_thime>,
    <alexsmobs:music_disc_daze>
] as IItemStack[];

for objet in anachronismes {
    JEI.removeAndHide(objet);
}


// ---------------------------------------------------------------------
//  5. LES INSECTES ET INVERTEBRES GEANTS IRREELS
//
//  Limaces d'un metre, cafards geants, fourmis tronconneuses, etc.
//  Leurs apparitions etant coupees, on retire leurs objets de JEI.
// ---------------------------------------------------------------------

val invertebresGeants = [
    <alexsmobs:banana_slug_slime>,
    <alexsmobs:banana_slug_slime_block>,
    <alexsmobs:crystalized_banana_slug_mucus>,
    <alexsmobs:cockroach_wing>,
    <alexsmobs:cockroach_wing_fragment>,
    <alexsmobs:cockroach_ootheca>,
    <alexsmobs:centipede_leg>,
    <alexsmobs:tarantula_hawk_wing>,
    <alexsmobs:tarantula_hawk_wing_fragment>,
    <alexsmobs:maggot>,
    <alexsmobs:gongylidia>,
    <alexsmobs:leafcutter_anthill>,
    <alexsmobs:leafcutter_ant_chamber>,
    <alexsmobs:leafcutter_ant_pupa>,
    <alexsmobs:triops_bucket>,
    <alexsmobs:dropbear_claw>,
    <alexsmobs:gustmaker>
] as IItemStack[];

for objet in invertebresGeants {
    JEI.removeAndHide(objet);
}


// ---------------------------------------------------------------------
//  CE QU'ON GARDE, ET POURQUOI
//
//  - Le « Animal Dictionary » reste, par la meme regle que le bestiaire
//    d'Exotic Birds (voir 09_oiseaux.zs) : un livre enlumine d'especes
//    est exactement ce qu'un lettre du XIVe siecle possedait. Seul son
//    don automatique a la connexion a ete coupe (giveBookOnStartup=false).
//  - Les fourrures, cornes, bois, cuirs, dents, plumes, seaux de vrais
//    poissons, viandes et venins de betes reelles : ce sont des
//    marchandises, elles nourrissent l'economie.
//  - Le lasso de liane, le dard, la maraca, les chapeaux simples
//    (fedora excepte) : credibles a l'oeil d'un paysan.
//
//  RESTE HORS DE PORTEE DE CE SCRIPT : rien. CraftTweaker ne peut pas
//  toucher aux effets d'un objet, seulement a sa recette et a sa
//  visibilite. Les objets ci-dessus n'etant plus ni fabricables ni
//  laches (leurs betes sont eteintes), ils sont hors d'atteinte.
// ---------------------------------------------------------------------
