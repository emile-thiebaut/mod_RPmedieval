// =====================================================================
//  ANACHRONISMES
//  On garde volontairement la boussole : la boussole marine arrive en
//  Europe vers 1300, c'est un objet medieval et pas un gadget moderne.
//
//  ⚠ L'HORLOGE l'etait tout autant, et elle est pourtant coupee — mais
//  PAS ici et PAS pour cette raison. Elle part dans 12_horloge.zs, parce
//  qu'elle est la piece qui rend le soufflet automatique, donc le feu
//  alimente automatique. C'est la regle « pas d'automatisation » qui la
//  condamne, pas la datation. Le raisonnement complet est en tete de
//  12_horloge.zs.
// =====================================================================

import crafttweaker.item.IItemStack;
import mods.jei.JEI;

val anachronismes = [
    <minecraft:jukebox>,
    <minecraft:tnt>,
    <minecraft:tnt_minecart>,
    <minecraft:fireworks>,
    <minecraft:firework_charge>
] as IItemStack[];

for objet in anachronismes {
    JEI.removeAndHide(objet);
}

// Les disques ne se craftent pas, mais ils ne doivent plus s'afficher :
// le vinyle au XIVe siecle, difficile a justifier.
val disques = [
    <minecraft:record_13>, <minecraft:record_cat>, <minecraft:record_blocks>,
    <minecraft:record_chirp>, <minecraft:record_far>, <minecraft:record_mall>,
    <minecraft:record_mellohi>, <minecraft:record_stal>, <minecraft:record_strad>,
    <minecraft:record_ward>, <minecraft:record_11>, <minecraft:record_wait>
] as IItemStack[];

for disque in disques {
    JEI.hide(disque);
}
