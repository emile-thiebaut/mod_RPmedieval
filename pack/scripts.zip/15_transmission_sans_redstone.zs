#modloaded betterwithmods

// =====================================================================
//  LA TRANSMISSION SANS REDSTONE, ET LE SOUFFLET A RESSORT QUI PART
//
//  Le fil conducteur : la transmission mecanique de BetterWithMods (les
//  engrenages, la version avancee du soufflet) passe par des composants
//  qui, dans le jar d'origine, se fabriquent avec de la poudre de
//  redstone. Rien de tout ca n'a de rapport avec la MECANIQUE des blocs
//  — un engrenage transmet la puissance qu'il transmettrait de toute
//  facon, quels que soient les ingredients de sa recette. Seule la
//  RECETTE change ici.
//
//  ⚠ Necessite ModTweaker pour l'ELEMENT CHAUFFANT : sa recette n'est
//  pas une recette d'etabli ordinaire mais une recette de CHAUDRON NON
//  ATTISE, un systeme a part que CraftTweaker seul ne sait pas toucher.
//  ModTweaker expose `mods.betterwithmods.Cauldron`, verifie present
//  dans <instance>\mods\modtweaker-4.0.20.11.jar.
//
//  Apres modification : REDEMARRAGE COMPLET.
// =====================================================================

import crafttweaker.item.IItemStack;
import mods.jei.JEI;


// ---------------------------------------------------------------------
//  1. Le soufflet avance (« Spring-Action Bellows ») — IL PART
//
//  ⚠ REVIREMENT DU 20 AOUT 2026, assume et explique ici pour qu'une
//  session future ne le defasse pas en croyant retrouver une recette
//  perdue.
//
//  Recette d'origine (assets/betterwithmods/recipes/blocks/mech/
//  advanced_bellows.json) :
//
//      .C.        C = horloge vanilla
//      SBS        S = ressort d'acier forge d'ame, B = soufflet simple
//      .G.        G = engrenage d'acier forge d'ame
//
//  Manuel du mod : « allows it to keep track of its timing and actuate
//  itself using Steel Springs » — une fois monte, il respire tout seul,
//  sans levier ni engrenage a couper.
//
//  La version precedente de ce fichier se contentait de lui retirer
//  l'horloge, et acceptait l'automatisation au motif qu'elle coute un
//  materiau de fin de partie. Cet arbitrage n'a plus lieu d'etre : le
//  POSTE DE SOUFFLETIER marche, il a ete eprouve en jeu, et il fait
//  exactement le meme travail en payant un homme pour le faire. Garder
//  a cote de lui une piece qui rend ce metier inutile, c'est garder la
//  seule machine du pack qui remplace un villageois — et se demander
//  ensuite pourquoi plus personne n'embauche de souffletier.
//
//  Le soufflet SIMPLE (<betterwithmods:bellows:0>) reste, evidemment :
//  c'est lui que le souffletier fait battre.
// ---------------------------------------------------------------------

JEI.removeAndHide(<betterwithmods:bellows:1>);


// ---------------------------------------------------------------------
//  2. Le loquet de redstone (betterwithmods:material:34) — la piece qui
//     entre dans TOUTE recette d'engrenage (wooden_gearbox, et la
//     poulie single_machine:1)
//
//  Recette d'origine (assets/betterwithmods/recipes/items/material/
//  material.redstone_latch.json) :
//
//      GGG        G = pepite d'or
//      .R.        R = poudre de redstone
//
//  C'est le verrou le plus large des trois : sans lui, aucun engrenage
//  ne se fabrique, donc aucune transmission de puissance mecanique du
//  tout — la scierie et le potier de MedievalCore en dependent autant
//  que le soufflet. On remplace la poudre de redstone par une pepite de
//  fer : la piece reste un petit loquet de metal, juste sans le grain de
//  poudre qui n'a plus cours sur ce serveur.
// ---------------------------------------------------------------------

recipes.remove(<betterwithmods:material:34>);

recipes.addShaped(<betterwithmods:material:34>, [
    [<ore:nuggetGold>, <ore:nuggetGold>, <ore:nuggetGold>],
    [null,              <ore:nuggetIron>, null]
]);


// ---------------------------------------------------------------------
//  3. L'ELEMENT chauffant (betterwithmods:material:27) — orpheline
//     depuis que scripts/13_hibachi.zs ne la demande plus
//
//  Recette d'origine (bulk, chaudron NON attise — bytecode de
//  CauldronRecipes.unstoked(), verifie) : fil (corde ou fibre de
//  chanvre) + poudre de blaze + poudre de redstone.
//
//  L'hibachi de ce pack ne la reclame plus du tout (voir
//  scripts/13_hibachi.zs, qui prend directement un lingot de fer). Cette
//  recette ne mene donc plus nulle part sur ce serveur — mais on la
//  corrige quand meme : elle reste une entree de JEI que le joueur peut
//  decouvrir, et une recette qui demande encore de la redstone induirait
//  en erreur. On lui retire la redstone ; la poudre de blaze reste, et
//  reste donc du Nether — hors de portee sur ce serveur, ce que cette
//  correction ne change pas et n'a pas a changer.
// ---------------------------------------------------------------------

mods.betterwithmods.Cauldron.remove([<betterwithmods:material:27>]);

// ⚠ L'ORDRE DES ARGUMENTS. La premiere version de cette ligne ecrivait
//   addUnstoked(<sortie>, null, [entrees]) — une signature qui n'existe
//   pas, et le script mourait a la ligne 108 sans que personne le voie :
//   le serveur ne demarrait jamais avec ces scripts (le dossier scripts\
//   du serveur avait quatre fichiers de retard sur celui du depot).
//   La vraie signature, lue au javap de
//   com.blamejared.compat.betterwithmods.Cauldron, est
//   addUnstoked(IIngredient[] entrees, IItemStack[] sorties) : LES DEUX
//   sont des tableaux, et les ENTREES viennent en premier.
mods.betterwithmods.Cauldron.addUnstoked(
    [<ore:string>, <ore:dustBlaze>, <ore:nuggetIron>],
    [<betterwithmods:material:27>]
);
