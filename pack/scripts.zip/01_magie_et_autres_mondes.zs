// =====================================================================
//  PAS DE MAGIE, PAS DE NETHER, PAS D'END
//  L'alchimie de Rustic est volontairement conservee : herbes, crucible
//  et elixirs, c'est l'apothicaire medieval, pas de la sorcellerie.
// =====================================================================

import crafttweaker.item.IItemStack;
import mods.jei.JEI;

val magie = [
    <minecraft:enchanting_table>,
    <minecraft:brewing_stand>,
    <minecraft:beacon>,
    <minecraft:ender_chest>,
    <minecraft:ender_eye>,
    <minecraft:golden_apple>,
    <minecraft:golden_apple:1>,
    <minecraft:end_crystal>
] as IItemStack[];

for objet in magie {
    JEI.removeAndHide(objet);
}

// Le coffre de l'Ender est le pire ennemi du commerce : il teleporte
// l'inventaire d'un bout a l'autre de la carte. Sans lui, transporter
// des marchandises redevient un vrai voyage, avec de vrais risques.

// Le livre reste, il sert a ecrire. Seule l'enluminure magique disparait.
recipes.remove(<minecraft:enchanted_book>);
