// =====================================================================
//  MISSION 1 : BLOCAGE DE LA REDSTONE
//  La poudre de redstone reste minable, mais ne sert plus a rien.
//  Elle n'est donc PAS masquee : le joueur doit pouvoir la ramasser
//  et constater par lui-meme qu'elle est inerte.
//
//  ⚠ EXCEPTION, decidee le 20 aout 2026 : LE LEVIER RESTE CRAFTABLE.
//  Il ne figure plus dans la liste `capteurs` plus bas.
//
//  Pourquoi : c'est la seule facon manuelle de faire battre le soufflet
//  de BetterWithMods, qui ne se contracte et relache que si un signal de
//  redstone est coupe puis rendu sur un engrenage en amont (verifie dans
//  le manuel du mod, assets/betterwithmods/documentation/docs/en_us/
//  blocks/bellows.md). Sans un levier qu'on peut fabriquer, le feu
//  alimente — le palier de chaleur qui debloque le suif, le savon, la
//  colle et la potasse — n'a plus AUCUN chemin, ni manuel ni automatique.
//
//  Ce n'est pas une bresche dans la regle « pas d'automatisation » : un
//  levier ne bascule pas tout seul, il faut une main a chaque fois — le
//  meme geste repetitif qu'une manivelle ou qu'un soufflet qu'on presse.
//  C'est ce geste que fr.medievalcore.tile.TileEntityPosteDeSouffletier
//  (a ecrire) paiera un homme pour repeter.
//
//  ⚠️ Ne pas « re-fermer » le levier en le croyant oublie ici par erreur.
//  Voir docs/09-betterwithmods-reference.md pour le raisonnement complet.
// =====================================================================

import crafttweaker.item.IItemStack;
import mods.jei.JEI;

// --- Mecanismes ------------------------------------------------------
val mecanismes = [
    <minecraft:piston>,
    <minecraft:sticky_piston>,
    <minecraft:repeater>,
    <minecraft:comparator>,
    <minecraft:observer>,
    <minecraft:redstone_lamp>,
    <minecraft:daylight_detector>,
    <minecraft:dispenser>,
    <minecraft:dropper>,
    <minecraft:redstone_torch>,
    <minecraft:redstone_block>,
    <minecraft:noteblock>,
    <minecraft:trapped_chest>,
    <minecraft:tripwire_hook>
] as IItemStack[];

// --- Capteurs et interrupteurs ---------------------------------------
// Le levier n'est PLUS dans cette liste : voir l'exception en tete de
// fichier. Tous les autres partent — aucun n'a le meme besoin.
val capteurs = [
    <minecraft:stone_button>,
    <minecraft:wooden_button>,
    <minecraft:stone_pressure_plate>,
    <minecraft:wooden_pressure_plate>,
    <minecraft:light_weighted_pressure_plate>,
    <minecraft:heavy_weighted_pressure_plate>
] as IItemStack[];

// --- Automatisation -------------------------------------------------
// L'entonnoir part avec le reste : sans lui, pas de tri automatique,
// donc le stockage reste un travail de bras.
val automatisation = [
    <minecraft:hopper>,
    <minecraft:hopper_minecart>
] as IItemStack[];

// --- Rails ----------------------------------------------------------
// On garde le rail simple, le wagon et le wagon-coffre : les chariots
// de mine sur rails de bois existaient bel et bien au XVIe siecle.
// Seuls les rails alimentes par la redstone disparaissent.
val rails = [
    <minecraft:golden_rail>,
    <minecraft:detector_rail>,
    <minecraft:activator_rail>
] as IItemStack[];

// --- Portes de fer --------------------------------------------------
// Sans redstone ni plaque de pression, elles ne s'ouvrent plus.
val portes = [
    <minecraft:iron_door>,
    <minecraft:iron_trapdoor>
] as IItemStack[];

for objet in mecanismes {
    JEI.removeAndHide(objet);
}
for objet in capteurs {
    JEI.removeAndHide(objet);
}
for objet in automatisation {
    JEI.removeAndHide(objet);
}
for objet in rails {
    JEI.removeAndHide(objet);
}
for objet in portes {
    JEI.removeAndHide(objet);
}

// La poudre elle-meme : plus aucune recette ne la consomme ni ne la produit
// (hors minage).
recipes.remove(<minecraft:redstone>);
