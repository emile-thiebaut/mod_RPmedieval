#modloaded exoticbirds

// =====================================================================
//  CE SCRIPT NE S'EXECUTE QUE SI EXOTIC BIRDS EST CHARGE
//
//  La ligne « #modloaded » ci-dessus n'est pas une precaution de style :
//  elle repare un defaut vecu. Le jar d'Exotic Birds a ete depose dans
//  les mods du serveur pendant que celui-ci tournait ; le serveur ne
//  l'avait donc pas, ce script a demande des objets qui n'existaient
//  pas, et CraftTweaker a rendu ceci au joueur connecte :
//
//      ERROR: 09_oiseaux.zs:51: Could not resolve <exoticbirds:phoenix_egg>
//      ERROR: Cannot remove recipes for a null item!
//      ERROR: Error executing 09_oiseaux.zs: null, NullPointerException
//
//  Le plus couteux n'est pas le message : c'est que le script MEURT a
//  la premiere ligne fautive. Tout ce qu'il devait faire ensuite ne se
//  fait pas, en silence, et l'on croit que le reglage est pose.
//
//  Regle generale : un script qui nomme un mod ABSENT D'UN DES DEUX
//  COTES porte un « #modloaded » en tete. Le mod manquant fait sauter
//  le script entier au lieu de le faire planter a moitie.
// =====================================================================

// =====================================================================
//  EXOTIC BIRDS : GARDER LA BASSE-COUR, COUPER LA VOLIERE TROPICALE
//
//  Le mod apporte 31 especes. Le filtre du serveur est toujours le meme :
//  « est-ce qu'un paysan du XIVe siecle comprendrait ce qu'il voit ? »
//
//  Trois reponses, donc trois traitements :
//
//  1. CE QUI RESTE, ET QUI EST UN CADEAU
//     Pigeon, canard, cygne, heron, pie, hibou, rouge-gorge, grue,
//     goeland, paon, pic. Toutes ces betes vivaient dans nos campagnes,
//     et le PIGEON est mieux qu'acceptable : le colombier est un
//     batiment seigneurial, un droit, un signe de rang. Il y a un poste
//     de metier a en tirer un jour.
//
//  2. CE QUI EST DE LA MAGIE, ET QUI SAUTE
//     Le PHENIX. Poussiere de phenix, plume de phenix, oeuf de phenix
//     qui eclot dans la lave. C'est exactement ce que
//     01_magie_et_autres_mondes.zs interdit partout ailleurs.
//
//  3. CE QUI EST UNE MACHINE, ET QUI SAUTE AUSSI
//     L'INCUBATEUR et l'IDENTIFICATEUR D'OEUFS. Une boite qui trie les
//     oeufs toute seule est de l'automatisation, et l'automatisation est
//     hors sujet sur ce serveur — c'est la meme regle qui a fait couper
//     les entonnoirs et les golems de Rats.
//
//  4. LES ESPECES EXOTIQUES — toucan, flamant, kiwi, autruche, manchot,
//     colibri, perroquet, kookaburra, perruche... Elles ne se
//     SUPPRIMENT pas ici : CraftTweaker touche aux recettes, pas aux
//     apparitions. Elles se brident dans InControl (spawn.json), ce qui
//     est bien plus interessant que de les effacer : l'espece existe
//     toujours, on ne la rencontre simplement jamais dans nos climats.
//     Elle devient une CURIOSITE DE MARCHAND — une bete qu'on n'a vue
//     que dans un livre, et qu'un negociant peut faire venir.
//     Voir config/incontrol/spawn.json.
//
//  IDENTIFIANTS verifies dans le jar (assets/exoticbirds/lang/en_us.lang
//  pour les objets, recipes/ pour les noms de registre des resultats).
//
//  Apres modification : REDEMARRAGE COMPLET.
// =====================================================================

import crafttweaker.item.IItemStack;
import mods.jei.JEI;


// ---------------------------------------------------------------------
//  1. Le phenix — la magie n'a pas sa place
// ---------------------------------------------------------------------

recipes.remove(<exoticbirds:phoenix_egg>);
JEI.removeAndHide(<exoticbirds:phoenix_egg>);
JEI.removeAndHide(<exoticbirds:phoenix_dust>);
JEI.removeAndHide(<exoticbirds:phoenix_feather>);


// ---------------------------------------------------------------------
//  2. Les machines a oeufs — pas d'automatisation
//
//  L'incubateur couve a votre place ; l'identificateur trie les oeufs
//  inconnus. Deux boites qui font le travail d'un homme, et sans homme
//  dedans : c'est la definition meme de ce qu'on refuse.
//
//  L'oeuf « non identifie » reste : sans trieuse, il devient ce qu'il
//  aurait toujours du etre — une surprise qu'on fait couver sous une
//  poule et qu'on decouvre a l'eclosion.
// ---------------------------------------------------------------------

recipes.remove(<exoticbirds:egg_incubator>);
recipes.remove(<exoticbirds:egg_sorter>);
JEI.removeAndHide(<exoticbirds:egg_incubator>);
JEI.removeAndHide(<exoticbirds:egg_sorter>);


// ---------------------------------------------------------------------
//  3. La cage d'or — le luxe, oui ; le gaspillage, non
//
//  Six lingots d'or pour une cage a oiseau, dans une economie ou l'ecu
//  vaut cent deniers, c'est un objet de prince. On la garde : un serveur
//  RP a besoin de choses que seuls les riches possedent.
//
//  La cage de FER, elle, garde sa recette d'origine : c'est l'objet
//  utile, celui du colombier.
// ---------------------------------------------------------------------

// (rien a faire : les deux recettes conviennent telles quelles)


// ---------------------------------------------------------------------
//  4. Le doublon du paon
//
//  Animania a deja son paon (animania:cooked_prime_peacock, au
//  catalogue des marchands a 26 deniers). Exotic Birds en ajoute un
//  second, avec sa propre viande.
//
//  On ne supprime rien : deux especes de paon dans un monde, c'est
//  vraisemblable. Mais la VIANDE d'oiseau d'Exotic Birds est generique
//  — « Raw Bird Meat » pour les 31 especes — donc elle ne va PAS au
//  catalogue des marchands : un negociant qui paierait le paon au prix
//  du pigeon casserait l'echelle des prix du palier 2.
//
//  La viande d'Exotic Birds reste donc de la nourriture, pas une
//  marchandise. C'est un choix d'economie, pas un oubli.
// ---------------------------------------------------------------------


// ---------------------------------------------------------------------
//  5. L'encyclopedie des oiseaux
//
//  Un livre qui liste les especes. C'est le seul objet « meta » du mod,
//  et il passe tres bien : un bestiaire enlumine est exactement ce qu'un
//  lettre du XIVe siecle possedait. On garde.
// ---------------------------------------------------------------------
