// =====================================================================
//  L'XP N'EST PLUS UNE RESSOURCE
//
//  La qualite d'une piece vient desormais de son metal, pas d'un rituel :
//  voir fr.medievalcore.forge dans MedievalCore. Il reste a retirer du jeu
//  tout ce qui faisait de l'experience une monnaie.
//
//  Le BLOC table d'enchantement est neutralise cote code (l'ouverture est
//  refusee dans GestionnaireInterdits) : les tables des villages et celles
//  deja posees ne pouvaient pas etre atteintes autrement. Ici on retire
//  seulement de quoi en fabriquer de nouvelles.
//
//  L'ENCLUME reste, elle : c'est elle qui sert a la trempe. Le niveau
//  d'experience qu'elle prend est rendu aussitot.
// =====================================================================

import crafttweaker.item.IItemStack;
import mods.jei.JEI;
import mods.betterwithmods.Crucible;

val rituels = [
    <minecraft:enchanting_table>,
    <minecraft:experience_bottle>
] as IItemStack[];

for objet in rituels {
    JEI.removeAndHide(objet);
}

// Les livres enchantes n'ont deja aucune recette : il n'y a rien a retirer,
// seulement a masquer. Sans table d'enchantement ils ne peuvent plus etre
// produits, et ceux qui trainent dans les structures n'ont plus d'emploi.
JEI.hide(<minecraft:enchanted_book>);


// =====================================================================
//  L'ACIER : UN SEUL METAL, ET IL NE PASSE PLUS PAR LE NETHER
// =====================================================================
//
//  Le pack en avait DEUX, et ils ne se parlaient pas :
//
//    * l'acier de Magistu Armory (<magistuarmory:steel_ingot>), qui sort
//      d'un four ordinaire — un lingot de fer dedans, un lingot d'acier
//      dehors. Verifie au bytecode : com.magistuarmory.init.ModItems
//      appelle GameRegistry.addSmelting(fer -> acier, 0.1f). C'est toutes
//      les armes et armures de chevalerie du serveur ;
//
//    * l'acier forge d'ame de BetterWithMods (<betterwithmods:material:14>),
//      qui demande une urne d'ame, du flux d'ame et de la poudre de
//      charbon au creuset attise. C'est toute la mecanique BWM : enclume,
//      engrenages, ressorts, plaques.
//
//  Deux problemes, opposes l'un a l'autre.
//
//  Le premier est que l'acier de Magistu ne coute RIEN. Un four, du
//  charbon, du fer : on obtient en une minute le metal qui devrait etre
//  l'aboutissement d'une filiere. Toute la progression de l'armurerie
//  s'effondre sur cette seule ligne.
//
//  Le second est que l'acier de BWM est enferme derriere le NETHER — l'urne
//  d'ame et le flux d'ame en viennent — et que ce serveur n'a pas de
//  Nether (voir 01_magie_et_autres_mondes.zs). La moitie mecanique du pack
//  etait donc inatteignable, definitivement.
//
//  On les fusionne : un acier, exigeant, et de ce monde-ci.
// ---------------------------------------------------------------------

// --- 1. Les dictionnaires ---------------------------------------------
//
//  ingotSteel est DEJA pose par Magistu (releve dans ModItems, aux cotes de
//  nuggetSteel) : la ligne est donc redondante, et on l'ecrit quand meme.
//  Une unification qui repose sur ce qu'un autre mod veut bien declarer est
//  une unification qui casse a sa prochaine version.
<ore:ingotSteel>.add(<magistuarmory:steel_ingot>);
<ore:ingotSteel>.add(<betterwithmods:material:14>);

//  Et dans les deux sens : ce que BWM appelle « acier forge d'ame », le
//  serveur l'appelle simplement acier. Les recettes de BWM qui passent par
//  cet ore acceptent donc l'acier de Magistu sans qu'on ait a les toucher.
<ore:ingotSoulforgedSteel>.add(<magistuarmory:steel_ingot>);

//  Le BLOC.
//
//  ⚠ <magistuarmory:steel_block> N'EXISTE PAS : le jar de Magistu Armory ne
//  contient aucun blockstate, donc aucun bloc — seulement des objets. La
//  ligne demandee aurait ete silencieusement sans effet. Le seul bloc
//  d'acier du pack est celui de BWM, et c'est lui qu'on inscrit.
<ore:blockSteel>.add(<betterwithmods:steel_block>);
<ore:blockSoulforgedSteel>.add(<betterwithmods:steel_block>);


// --- 2. Plus de fer qui devient acier dans un four ---------------------
//
//  On retire par la SORTIE : c'est la seule facon sure d'attraper une
//  recette de fusion posee en code par un autre mod, dont on ne connait ni
//  le nom ni l'ordre d'enregistrement.
furnace.remove(<magistuarmory:steel_ingot>);


// --- 3. L'acier se fait au creuset attise ------------------------------
//
//  Le creuset de BetterWithMods, sous un feu ATTISE (hibachi + soufflet) :
//  c'est deja la piece maitresse de la metallurgie du pack, et c'est le seul
//  endroit du jeu ou l'on puisse mettre trois choses ensemble et attendre.
//
//  La recette dit ce qu'est l'acier, et c'est ce qui la rend juste :
//
//    * du FER, la matiere ;
//    * du CARBONE — poudre de charbon (material:18) ou poudre de charbon de
//      bois (material:37) — c'est lui qui fait l'acier. Les deux conviennent,
//      parce qu'un charbonnier doit pouvoir travailler sans mine ;
//    * du SABLE, le fondant : c'est ce qui capte les impuretes et remonte en
//      laitier. <ore:sand> est enregistre par Forge lui-meme, donc n'importe
//      quel sable du pack fait l'affaire.
//
//  Verifie au bytecode : la signature est
//  mods.betterwithmods.Crucible.addStoked(IIngredient[], IItemStack[]),
//  et les metadonnees viennent de l'enum ItemMaterial$EnumMaterial —
//  14 = INGOT_STEEL, 18 = COAL_DUST, 37 = CHARCOAL_DUST. Le fichier de
//  langue ne suffisait pas a les compter : il contient une entree en double.
Crucible.addStoked(
    [
        <minecraft:iron_ingot>,
        <betterwithmods:material:18> | <betterwithmods:material:37>,
        <ore:sand>
    ],
    [<magistuarmory:steel_ingot>]);


// --- 4. Les recettes de BWM qui nommaient son acier en dur -------------
//
//  L'enclume d'acier demandait huit <betterwithmods:material:14> par son
//  nom, sans passer par aucun ore : l'inscription au dictionnaire ne
//  l'aurait donc jamais atteinte. C'est la seule recette de grille dans ce
//  cas — les engrenages, ressorts et plaques d'acier sont des recettes
//  d'ENCLUME, et l'enclume est justement ce qu'il faut d'abord pouvoir
//  construire.
recipes.remove(<betterwithmods:steel_anvil>);
recipes.addShaped("medievalcore_enclume_acier", <betterwithmods:steel_anvil>, [
    [<ore:ingotSteel>, <ore:ingotSteel>, <ore:ingotSteel>],
    [null,             <ore:ingotSteel>, null],
    [<ore:ingotSteel>, <ore:ingotSteel>, <ore:ingotSteel>]]);


// --- 5. Le pont entre les deux lingots ---------------------------------
//
//  Les recettes d'enclume de BWM — engrenage, ressort, plaque — nomment son
//  acier a lui, et elles vivent en code : il y en a trop pour les reecrire
//  une a une, et les reecrire serait de toute facon les figer.
//
//  Une conversion UN POUR UN dans les deux sens regle la question d'un
//  trait. Ce n'est pas une duplication — on echange un lingot contre un
//  lingot — et ce n'est pas non plus un contournement : l'acier de BWM n'a
//  plus d'autre source que celle-ci, puisque le Nether n'existe pas.
//
//  Autrement dit : le creuset fabrique LE lingot d'acier du serveur, et
//  cette paire de recettes lui donne les deux visages dont le pack a besoin.
recipes.addShapeless("medievalcore_acier_vers_bwm",
    <betterwithmods:material:14>, [<magistuarmory:steel_ingot>]);
recipes.addShapeless("medievalcore_acier_depuis_bwm",
    <magistuarmory:steel_ingot>, [<betterwithmods:material:14>]);
