#modloaded davincisvessels

// =====================================================================
//  DAVINCI'S VESSELS (ARCHIMEDES' SHIPS) : NAVIGATION MÉDIÉVALE
//
//  Davinci's Vessels permet de transformer des constructions de blocs
//  en navires mobiles. Toutefois, le mod intègre d'origine deux éléments
//  anachroniques pour un univers médiéval :
//
//    1. Les BALLONS (aéronefs / montgolfières) : le vol aérien n'a pas
//       sa place au Moyen Âge ; seuls les navires maritimes et fluviaux
//       sont autorisés.
//    2. Le MOTEUR À VAPEUR : la propulsion à vapeur est une machine de
//       l'ère industrielle, incompatible avec notre époque.
//
//  De plus, les instruments de bord légitimes (la jauge et le point
//  d'ancrage) exigeaient à l'origine de la poudre de redstone, ressource
//  supprimée du serveur :
//    - La jauge d'orientation reçoit une pépite d'or (le pivot de
//      l'aiguille, comme la boussole marine et le cadran des saisons) ;
//    - Le point d'ancrage est entièrement forgé de fer (lingots et bloc
//      de fer pour le treuil et le grappin).
//
//  Après modification : REDÉMARRAGE COMPLET DU SERVEUR ET DU CLIENT.
// =====================================================================

import crafttweaker.item.IItemStack;
import mods.jei.JEI;


// ---------------------------------------------------------------------
//  1. SUPPRESSION DES BALLONS (PAS D'AÉRONEFS)
//
//  Chaque variante de couleur est retirée de l'établi et masquée dans
//  JEI pour empêcher toute construction de vaisseau volant.
// ---------------------------------------------------------------------

val ballons = [
    <davincisvessels:balloon:0>,
    <davincisvessels:balloon:1>,
    <davincisvessels:balloon:2>,
    <davincisvessels:balloon:3>,
    <davincisvessels:balloon:4>,
    <davincisvessels:balloon:5>,
    <davincisvessels:balloon:6>,
    <davincisvessels:balloon:7>,
    <davincisvessels:balloon:8>,
    <davincisvessels:balloon:9>,
    <davincisvessels:balloon:10>,
    <davincisvessels:balloon:11>,
    <davincisvessels:balloon:12>,
    <davincisvessels:balloon:13>,
    <davincisvessels:balloon:14>,
    <davincisvessels:balloon:15>
] as IItemStack[];

for ballon in ballons {
    recipes.remove(ballon);
    JEI.removeAndHide(ballon);
}
recipes.remove(<davincisvessels:balloon:*>);


// ---------------------------------------------------------------------
//  2. SUPPRESSION DU MOTEUR À VAPEUR (PAS DE MACHINERIE INDUSTRIELLE)
//
//  Le navire médiéval avance à la force du vent et des rames (la barre
//  de gouvernail suffit pour mouvoir l'embarcation).
// ---------------------------------------------------------------------

recipes.remove(<davincisvessels:engine>);
JEI.removeAndHide(<davincisvessels:engine>);


// ---------------------------------------------------------------------
//  3. REFORGE DE LA JAUGE DE NAVIGATION (SANS REDSTONE)
//
//  Recette d'origine : fer, or, verre et redstone au centre.
//  La redstone est remplacée par une pépite d'or, représentant l'axe
//  pivot inoxydable des aiguilles marines (comme dans 16_redstone_residuelle.zs).
// ---------------------------------------------------------------------

recipes.remove(<davincisvessels:gauge:0>);

recipes.addShaped("medievalcore_jauge_davinci_1", <davincisvessels:gauge:0>, [
    [<ore:blockGlassColorless>, <ore:ingotIron>,  <ore:blockGlassColorless>],
    [<ore:ingotIron>,           <ore:nuggetGold>, <ore:ingotGold>],
    [null,                      <ore:ingotGold>,  null]
]);

recipes.addShaped("medievalcore_jauge_davinci_2", <davincisvessels:gauge:0>, [
    [<ore:blockGlassColorless>, <ore:ingotGold>,  <ore:blockGlassColorless>],
    [<ore:ingotGold>,           <ore:nuggetGold>, <ore:ingotIron>],
    [null,                      <ore:ingotIron>,  null]
]);


// ---------------------------------------------------------------------
//  4. REFORGE DU POINT D'ANCRAGE (SANS REDSTONE)
//
//  Recette d'origine : fer forgé, bloc de fer et deux poudres de redstone.
//  Les deux redstones sont remplacées par des lingots de fer : le point
//  d'ancrage et son cabestan sont un solide ouvrage de ferronnerie marine.
// ---------------------------------------------------------------------

recipes.remove(<davincisvessels:anchorpoint>);

recipes.addShaped("medievalcore_point_ancrage_davinci", <davincisvessels:anchorpoint>, [
    [null,            <ore:ingotIron>, null],
    [<ore:ingotIron>, <ore:ingotIron>, <ore:ingotIron>],
    [<ore:ingotIron>, <ore:blockIron>, <ore:ingotIron>]
]);
