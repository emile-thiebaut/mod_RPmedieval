// =====================================================================
//  LA LUMIERE — reparer la torche
//
//  Constat des verifications en jeu (docs/12 §2.4) : Realistic Torches
//  retire la recette de <minecraft:torch> par sa configuration, et la
//  seule facon d'en rallumer une passait par de la GLOWSTONE, qui ne
//  s'obtient que dans le Nether — ferme sur ce serveur.
//
//  Il n'y avait donc AUCUNE source de lumiere renouvelable, ce qui bloque
//  tout, mine comprise, bien avant le village.
//
//  La torche redevient donc fabricable, mais plus cherement qu'en vanilla :
//  il faut du SUIF. C'est exactement la chandelle de suif medievale, et ca
//  branche l'eclairage sur l'elevage — donc sur un metier.
//
//  <betterwithmods:material:13> = Tallow. La metadonnee vaut l'ordinal de
//  ItemMaterial$EnumMaterial (verifie : getMetadata() { return ordinal(); }),
//  et TALLOW y est le quatorzieme, donc 13.
//
//  ATTENTION : 'minecraft:torch' a ete retire de la liste removeRecipes de
//  config/realistictorches.cfg. Sans ca, l'ordre entre la suppression du mod
//  et l'ajout de CraftTweaker n'est pas garanti. C'est CraftTweaker qui tient
//  la recette, du debut a la fin, et on la voit en entier ici.
// =====================================================================

// On retire d'abord la recette vanilla : un baton et du charbon donneraient
// quatre torches pour rien, et la torche eteinte de Realistic Torches n'aurait
// plus aucun sens.
recipes.remove(<minecraft:torch>);

// La chandelle de suif : une hampe, une braise, et de quoi la faire tenir.
// Le charbon de bois convient autant que le charbon mineral — d'ou le joker
// sur la metadonnee.
recipes.addShaped("medievalcore_torche_de_suif",
    <minecraft:torch> * 4,
    [[<betterwithmods:material:13>],
     [<minecraft:coal:*>],
     [<minecraft:stick>]]);

// La torche eteinte de Realistic Torches garde sa recette d'origine (baton +
// charbon) : elle reste le moyen bon marche, et il faut un briquet pour
// l'allumer. Les deux chemins coexistent, et c'est voulu :
//
//   - torche eteinte  -> pas chere, mais il faut du feu pour l'allumer
//   - torche de suif  -> chere, mais elle part allumee
