#modloaded betterwithmods sereneseasons toughasnails rustic dawnoftimebuilder alexsmobs

// =====================================================================
//  LA REDSTONE QUI RESTAIT — LA PART DES MODS
//
//  Suite de 16_redstone_residuelle.zs, qu'il faut lire d'abord : c'est
//  lui qui explique le balayage et pourquoi il y a deux fichiers.
//
//  Deux traitements, selon la nature de l'objet :
//
//    * un objet LEGITIME dont la recette demandait de la poudre est
//      REFORGE — on remplace le grain, on garde l'objet ;
//    * un objet qui n'est de la redstone que par nature (ampoule,
//      plaque de pression, machine a vent) part avec le reste : c'est
//      la regle de 00_redstone.zs, pas une nouvelle decision.
//
//  Ce qui n'est PAS ici, et pourquoi :
//    - les rails detecteurs de BetterWithMods : la fonctionnalite
//      DetectorRail est a false dans config/betterwithmods.cfg, donc
//      leurs blocs ne sont pas enregistres du tout (verifie : le
//      ModuleLoader du mod n'appelle preInit que sur les
//      fonctionnalites actives). Les nommer ici casserait ce script ;
//    - le distributeur de blocs, le detecteur et le buddy block de
//      BetterWithMods : leurs recettes d'enclume demandent une TORCHE
//      de redstone, qui n'est deja plus fabricable depuis
//      00_redstone.zs ;
//    - la poudre de blaze et la poussiere de pierre lumineuse : elles
//      restent hors de portee (pas de Nether), ce qui ne nous regarde
//      pas — on ne corrige ici que la redstone.
//
//  Apres modification : REDEMARRAGE COMPLET.
// =====================================================================

import crafttweaker.item.IItemStack;
import mods.jei.JEI;


// ---------------------------------------------------------------------
//  1. LE CADRAN DES SAISONS de Serene Seasons
//
//  Recette d'origine : un anneau de quartz autour d'un grain de poudre.
//
//  L'objet reste : sur un serveur ou les saisons commandent les semis,
//  savoir ou l'on en est de l'annee est une information de paysan, pas
//  un gadget. Ce n'est pas l'horloge de 12_horloge.zs — il ne donne pas
//  l'heure, il donne la saison, et rien dans BetterWithMods ne le
//  reclame pour rendre un soufflet automatique.
//
//  Le grain de poudre devient une pepite d'or : le gnomon du cadran.
// ---------------------------------------------------------------------

recipes.remove(<sereneseasons:season_clock>);

recipes.addShaped("medievalcore_cadran_des_saisons", <sereneseasons:season_clock>, [
    [null,             <ore:gemQuartz>,  null],
    [<ore:gemQuartz>,  <ore:nuggetGold>, <ore:gemQuartz>],
    [null,             <ore:gemQuartz>,  null]
]);


// ---------------------------------------------------------------------
//  2. LE THERMOMETRE de Tough As Nails
//
//  Recette d'origine : un anneau de verre autour d'un grain de poudre.
//
//  Les bobines de chauffage et de refroidissement de ce mod ont ete
//  coupees dans 05_nettoyage_mods.zs, mais le thermometre n'est pas du
//  meme ordre : il ne CHANGE rien, il MONTRE. Sur un pack ou le froid
//  tue, retirer le seul instrument qui dit qu'on a froid ne rend pas le
//  jeu plus medieval, seulement plus opaque.
//
//  Le grain de poudre devient une pepite de fer : l'aiguille.
// ---------------------------------------------------------------------

recipes.remove(<toughasnails:thermometer>);

recipes.addShaped("medievalcore_thermometre", <toughasnails:thermometer>, [
    [null,                      <ore:blockGlassColorless>, null],
    [<ore:blockGlassColorless>, <ore:nuggetIron>,          <ore:blockGlassColorless>],
    [null,                      <ore:blockGlassColorless>, null]
]);


// ---------------------------------------------------------------------
//  3. LES CHANDELIERS BASCULANTS de Rustic
//
//  Trois objets — <rustic:candle_lever>, sa version doree et sa version
//  argentee (celle-ci enregistree dans le code du mod et non dans un
//  fichier de recette, verifie au bytecode de
//  rustic.common.crafting.Recipes). Tous les trois : une chandelle
//  posee sur un grain de poudre.
//
//  Ils restent, et ils meritent mieux qu'un simple sursis : ce sont des
//  LEVIERS deguises en chandeliers. Un souffletier qui bascule un
//  chandelier mural est infiniment plus juste, a l'oeil, qu'un
//  souffletier qui bascule une manette de pierre.
//
//  (Le poste de souffletier ne cherche pour l'instant qu'un
//  <minecraft:lever> — voir TileEntityPosteDeSouffletier. Elargir sa
//  recherche a ces trois-la est note dans la feuille de route.)
//
//  Le grain de poudre devient une pepite de fer : la charniere.
// ---------------------------------------------------------------------

recipes.remove(<rustic:candle_lever>);
recipes.addShaped("medievalcore_chandelier_basculant", <rustic:candle_lever>, [
    [<rustic:candle>],
    [<ore:nuggetIron>]
]);

recipes.remove(<rustic:candle_lever_gold>);
recipes.addShaped("medievalcore_chandelier_basculant_or", <rustic:candle_lever_gold>, [
    [<rustic:candle_gold>],
    [<ore:nuggetIron>]
]);

recipes.remove(<rustic:candle_lever_silver>);
recipes.addShaped("medievalcore_chandelier_basculant_argent", <rustic:candle_lever_silver>, [
    [<rustic:candle_silver>],
    [<ore:nuggetIron>]
]);


// ---------------------------------------------------------------------
//  4. L'ARMURE O-YOROI de Dawn of Time
//
//  Quatre pieces, toutes fabriquees avec des BLOCS de redstone et de la
//  poudre. C'est de la couleur, pas du mecanisme : l'o-yoroi japonais
//  est une armure lamellaire lacee de cordons, et ces cordons sont
//  rouges. Le mod s'est servi de la redstone comme d'un colorant.
//
//  On remplace donc terme a terme, sans toucher a la forme des
//  recettes : bloc de redstone -> laine rouge, poudre -> rouge de
//  garance. Le charbon en bloc reste : c'est le laquage noir.
// ---------------------------------------------------------------------

recipes.remove(<dawnoftimebuilder:o_yoroi_armor_head>);
recipes.addShaped("medievalcore_o_yoroi_casque", <dawnoftimebuilder:o_yoroi_armor_head>, [
    [<minecraft:gold_ingot>, <minecraft:dye:1>,      <minecraft:gold_ingot>],
    [<minecraft:wool:14>,    <minecraft:gold_ingot>, <minecraft:wool:14>]
]);

recipes.remove(<dawnoftimebuilder:o_yoroi_armor_chest>);
recipes.addShaped("medievalcore_o_yoroi_cuirasse", <dawnoftimebuilder:o_yoroi_armor_chest>, [
    [<minecraft:wool:14>,    null,                   <minecraft:wool:14>],
    [<minecraft:coal_block>, <minecraft:gold_ingot>, <minecraft:coal_block>],
    [<minecraft:dye:1>,      <minecraft:dye:1>,      <minecraft:dye:1>]
]);

recipes.remove(<dawnoftimebuilder:o_yoroi_armor_legs>);
recipes.addShaped("medievalcore_o_yoroi_jambieres", <dawnoftimebuilder:o_yoroi_armor_legs>, [
    [<minecraft:dye:1>,      <minecraft:dye:1>, <minecraft:dye:1>],
    [<minecraft:coal_block>, null,              <minecraft:coal_block>],
    [<minecraft:wool:14>,    null,              <minecraft:wool:14>]
]);

recipes.remove(<dawnoftimebuilder:o_yoroi_armor_feet>);
recipes.addShaped("medievalcore_o_yoroi_solerets", <dawnoftimebuilder:o_yoroi_armor_feet>, [
    [<minecraft:wool:14>,    null, <minecraft:wool:14>],
    [<minecraft:coal_block>, null, <minecraft:coal_block>]
]);


// ---------------------------------------------------------------------
//  5. LE FILAMENT de BetterWithMods
//
//  Recette de chaudron non attise : un fil + poussiere de pierre
//  lumineuse + poudre de redstone. Elle ne mene nulle part sur ce
//  serveur — la pierre lumineuse est du Nether, et l'ampoule qu'elle
//  sert part au point 6 — mais elle reste une fiche visible dans JEI,
//  exactement comme l'element chauffant de
//  15_transmission_sans_redstone.zs. On la corrige pour la meme raison :
//  une recette qui demande encore de la poudre induit en erreur.
//
//  <betterwithmods:material:19> = FILAMENT (l'ordinale dans
//  ItemMaterial$EnumMaterial, verifiee au javap : GEAR=0, TALLOW=13,
//  FILAMENT=19, POLISHED_LAPIS=20, ELEMENT=27, REDSTONE_LATCH=34).
// ---------------------------------------------------------------------

mods.betterwithmods.Cauldron.remove([<betterwithmods:material:19>]);

// Signature : addUnstoked(entrees[], sorties[]) — les deux sont des
// tableaux, les entrees d'abord. Voir la note de
// 15_transmission_sans_redstone.zs : l'ordre inverse ne leve pas
// d'avertissement, il tue le script entier.
mods.betterwithmods.Cauldron.addUnstoked(
    [<ore:string>, <ore:dustGlowstone>, <ore:nuggetIron>],
    [<betterwithmods:material:19>]
);


// ---------------------------------------------------------------------
//  6. CE QUI PART AVEC LE RESTE DE LA REDSTONE
//
//  Aucun de ces quatre-la n'est un objet legitime a qui il manquerait
//  seulement un ingredient : ils SONT de la redstone.
//
//    * l'ampoule de BetterWithMods (« Light Block ») : une lampe
//      electrique a filament, dans un pack ou la lumiere se fait au
//      suif (voir 07_lumiere.zs) ;
//    * la machine a vent d'Alex's Mobs : un souffleur qu'on declenche
//      par un signal. Son oeil de guster est deja masque par
//      11_alexsmobs.zs, mais sa fiche montrait encore de la poudre ;
//    * la plaque de pression d'acier de BetterWithMods : une plaque de
//      pression, c'est-a-dire tout ce que 00_redstone.zs a retire.
//
//  Le lapis poli s'y ajoute pour une autre raison : c'est un materiau
//  decoratif dont la recette d'ENCLUME demande de la poudre. On ne
//  peut pas retirer proprement une recette d'enclume sans en redonner
//  la grille exacte ; on masque donc l'objet, ce qui retire la fiche de
//  JEI. Meme traitement pour la plaque d'acier, qui est elle aussi une
//  recette d'enclume — et l'enclume d'acier de BetterWithMods est de
//  toute facon un objet de fin de partie que personne n'aura le
//  vendredi de l'ouverture.
// ---------------------------------------------------------------------

val redstoneDeguisee = [
    <betterwithmods:light>,
    <alexsmobs:gustmaker>,
    <betterwithmods:steel_pressure_plate>,
    <betterwithmods:material:20>
] as IItemStack[];

for objet in redstoneDeguisee {
    JEI.removeAndHide(objet);
}


// ---------------------------------------------------------------------
//  7. L'ENTONNOIR FILTRANT de BetterWithMods
//
//  L'objet est <betterwithmods:single_machine:2>. Ce n'est PAS
//  <betterwithmods:hopper> : celui-la est le nom du BLOC POSE, comme
//  pour la plaque tournante de 12_horloge.zs.
//
//  Recette d'origine (assets/betterwithmods/recipes/blocks/mech/
//  single_machine_2.json, lue telle quelle dans le jar) :
//
//      S S        S = bardage de bois  (#SIDING_WOOD)
//      GPG        G = engrenage de bois (ore gearWood)
//       C         P = PLAQUE DE PRESSION DE BOIS
//                 C = coin de bois     (#CORNER_WOOD)
//
//  La plaque de pression est partie avec les capteurs de 00_redstone.zs.
//  L'entonnoir filtrant devenait donc INFABRICABLE — et c'est un vrai
//  probleme, parce qu'il n'a rien d'un automate : il ne bouge que sous
//  puissance mecanique, donc sous la manivelle d'un homme, et c'est lui
//  qui trie le gravier, le sable et les tamis. Le retirer aurait ferme
//  la moitie du travail de BetterWithMods au nom d'une piece qu'il
//  n'utilise meme pas comme capteur : la plaque n'etait la que pour sa
//  FORME, un volet a plat au fond de la tremie.
//
//  On la remplace par une trappe de bois, qui est exactement ce volet et
//  qui reste fabricable. Rien d'autre ne bouge — meme grille, memes
//  engrenages, meme cout.
// ---------------------------------------------------------------------

recipes.remove(<betterwithmods:single_machine:2>);

recipes.addShaped("medievalcore_entonnoir_filtrant",
    <betterwithmods:single_machine:2>, [
    [<betterwithmods:wood_siding:*>, null,                        <betterwithmods:wood_siding:*>],
    [<ore:gearWood>,                 <minecraft:trapdoor>,        <ore:gearWood>],
    [null,                           <betterwithmods:wood_corner:*>, null]
]);
