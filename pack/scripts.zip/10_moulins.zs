#modloaded betterwithmods

// =====================================================================
//  LES MOULINS : COUPER LE MOULIN VERTICAL
//
//  BetterWithMods propose trois generateurs mecaniques, tous poses par
//  le meme objet, betterwithmods:axle_generator, distingues par leur
//  METADONNEE.
//
//  ⚠️⚠️ LE NOM DES FICHIERS DE RECETTE MENT. Une premiere version de ce
//  script lisait les noms de fichier (assets/betterwithmods/recipes/
//  blocks/mech/*.json) et en deduisait :
//
//      windmill.json           -> data 0  (correct)
//      vertical_windmill.json  -> data 1  (FAUX)
//      waterwheel.json         -> data 2  (FAUX)
//
//  et coupait donc le 1 en croyant couper le moulin vertical. En jeu,
//  c'est la ROUE A AUBE qui a disparu de l'etabli — la scierie et le
//  potier, qui exigent tous deux une roue ou un moulin a portee, se
//  sont retrouves sans aucun moyen de fonctionner au bord d'une riviere.
//
//  Le mensonge est demontre au bytecode de ItemAxleGenerator, deux fois
//  independamment :
//
//    1. Le tableau `names` du constructeur (celui qui donne le nom
//       affiche) : {0: "windmill", 1: "waterwheel", 2: "windmill_vertical"}.
//
//    2. `isHorizontalDeviceValid`, qui decide QUEL BLOC poser :
//       `if (metadonnee == 1) placer BWMBlocks.WATERWHEEL`. Rien
//       d'ambigu : c'est un test d'egalite sur l'entier de metadonnee,
//       pas une supposition.
//
//  La bonne table, verifiee au comportement reel du bloc et non au nom
//  d'un fichier :
//
//      data 0  Windmill (horizontal)   les pales tournent a plat, 13x13
//      data 1  Waterwheel              la roue a aube, 5x5 au fil de l'eau
//      data 2  Vertical Windmill       les pales dans un plan vertical
//
//  On COUPE le 2 (vertical), on garde le 0 (horizontal) et le 1 (roue).
//
//  Pourquoi ce choix : c'est le moulin VERTICAL qui a ete juge le
//  mauvais a l'usage. On garde donc l'horizontal, qui tourne bien, et
//  la roue a aube pour qui a une riviere. Deux facons de moudre, deux
//  terrains differents, et un village qui doit choisir.
//
//  Ce qui ne change RIEN au reste du mod : le moulin horizontal pose
//  betterwithmods:windmill, la roue a aube betterwithmods:waterwheel —
//  deux classes de bloc distinctes (verifie au bytecode). Aucun code de
//  MedievalCore ne cherche l'un ou l'autre par son nom : la scierie et
//  le potier servent la SCIE et le TOUR de BWM directement, et ce sont
//  ces deux blocs-la qui exigent une source de puissance mecanique
//  quelque part en amont — peu importe qu'elle vienne d'un moulin ou
//  d'une roue. Rien a changer de ce cote.
//
//    * le domaine est « betterwithmods » et NON « bwm » : le prefixe des
//      clefs de langue n'est pas un domaine de registre ;
//    * #modloaded en tete : sans BetterWithMods dans le pack, ce script
//      se saute entier au lieu de planter a la premiere ligne.
//
//  LA LECON A RETENIR, au-dela de ce fichier precis : le nom d'un
//  fichier de recette ne prouve rien sur ce que la recette fabrique
//  reellement. On verifie au bytecode, comme pour les blockstates et
//  les .lang — voir docs/reference/02-identifiants.md.
//
//  Apres modification : REDEMARRAGE COMPLET.
// =====================================================================

import crafttweaker.item.IItemStack;
import mods.jei.JEI;


// ---------------------------------------------------------------------
//  Le moulin vertical s'en va (data 2, PAS data 1 : voir plus haut)
// ---------------------------------------------------------------------

recipes.remove(<betterwithmods:axle_generator:2>);
JEI.removeAndHide(<betterwithmods:axle_generator:2>);


// ---------------------------------------------------------------------
//  Ce qui reste, et pourquoi on n'y touche pas
//
//    * <betterwithmods:axle_generator:0>  le moulin horizontal. Il lui
//      faut 13x13 de degage : un ouvrage de village, pas de cabane.
//
//    * <betterwithmods:axle_generator:1>  la roue a aube. Il lui faut
//      5x5 au fil de l'eau. Moins cher et plus petite, mais il faut la
//      riviere — donc il faut avoir bati au bon endroit.
//
//  La MANIVELLE (betterwithmods:hand_crank) reste elle aussi. Elle ne
//  fait tourner qu'un axe court et s'arrete des qu'on lache : elle
//  depanne, elle ne remplace pas un moulin. La couper priverait le
//  joueur de tout moyen de moudre son premier sac de farine avant
//  d'avoir bati son village, ce qui est le contraire du but.
// ---------------------------------------------------------------------
