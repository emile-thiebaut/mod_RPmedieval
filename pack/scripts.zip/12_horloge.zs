// =====================================================================
//  L'HORLOGE, ET CE QU'ELLE OUVRAIT
//
//  02_anachronismes.zs gardait l'horloge en disant, a juste titre, que
//  les premieres horloges mecaniques sont bien du XIVe siecle. Ce n'est
//  donc PAS pour anachronisme qu'elle part ici : c'est parce qu'elle est
//  la piece qui rend le feu automatique.
//
//  Le raisonnement, a ne pas defaire sans le relire :
//
//    - le feu ALIMENTE de BetterWithMods (celui qui debloque le creuset,
//      le savon, la colle, la poterie cuite) demande un hibachi souffle
//      par un SOUFFLET ;
//    - un soufflet doit monter et descendre en rythme, donc il lui faut
//      une source de puissance intermittente ;
//    - la PLAQUE TOURNANTE est cette source, et sa recette demandait une
//      HORLOGE.
//
//  Horloge craftable = soufflet automatique = feu qui s'entretient tout
//  seul = plus aucun ouvrier devant la forge. C'est exactement ce que la
//  regle « pas d'automatisation » interdit.
//
//  On coupe donc l'horloge, et on refait la plaque tournante sans elle :
//  elle reste utile au potier, mais elle ne suffit plus a entretenir un
//  feu. Le feu alimente se tient a la MANIVELLE, par un homme.
//
//  ⚠ NE PAS « retablir » l'horloge en la croyant supprimee par erreur.
//  Voir docs/09-betterwithmods-reference.md, partie sur le feu alimente.
// =====================================================================

import mods.jei.JEI;

// --- L'horloge ------------------------------------------------------
// Sa recette vanilla (4 lingots d'or + 1 poudre de redstone) survivait a
// 00_redstone.zs : celui-ci ne retire que les recettes qui PRODUISENT de
// la redstone, pas celles qui en consomment.
JEI.removeAndHide(<minecraft:clock>);

// --- La plaque tournante, sans horloge --------------------------------
// L'objet est <betterwithmods:single_machine:3>. Ce n'est PAS
// <betterwithmods:turntable> : ce dernier est le nom du BLOC POSE, pas
// celui de l'objet. Verifie dans le .lang du jar :
//   tile.bwm:single_machine.3.name=Turntable
// (meme piege que les fromages d'Animania — voir 02-identifiants.md)
//
// <betterwithmods:material:0> est l'ENGRENAGE de bois : la metadonnee est
// l'ordinale de ItemMaterial$EnumMaterial, et GEAR y est en tete.
recipes.remove(<betterwithmods:single_machine:3>);

recipes.addShaped(<betterwithmods:single_machine:3>, [
    [<ore:plankWood>, <betterwithmods:material:0>, <ore:plankWood>],
    [<ore:stone>,     <ore:stone>,                 <ore:stone>],
    [<ore:stone>,     <betterwithmods:material:0>, <ore:stone>]
]);
