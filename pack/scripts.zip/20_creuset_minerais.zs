// =====================================================================
//  LES MINERAIS DE GEOLOSYS SE FONDENT AU CREUSET ATTISE (08/10/2026)
//
//  Geolosys ne laisse pas tomber de minerai mais des AMAS (geolosys:cluster),
//  qui se fondent au four ordinaire. Le creuset de BetterWithMods, lui, ne
//  connaissait aucun minerai : son module HCOres est coupe dans
//  betterwithmods.cfg (B:HCOres=false), et c'est lui seul qui y aurait mis
//  des recettes de fonte. Un forgeron qui avait monte son creuset et son
//  soufflet ne pouvait donc rien y fondre de ce qu'il avait creuse.
//
//  On passe par le DICTIONNAIRE et jamais par les metadonnees :
//  verifie au bytecode (ItemCluster.registerOreDict), chaque amas s'inscrit
//  sous « ore » + son metal — oreIron, oreCopper, oreTin... Les blocs de
//  minerai pris a la soie y sont aussi, et fondent de meme.
//
//  Un amas rend UN lingot, exactement comme au four : le creuset est le
//  poste du forgeron, pas une planche a billets. Ce qu'il apporte, c'est de
//  fondre au meme endroit que l'acier, sous le meme feu.
//
//  Un metal sans lingot au dictionnaire (uranium, osmium, yellorium) est
//  saute de lui-meme : ni recette fantome, ni erreur au demarrage.
//
//  Signature verifiee : mods.betterwithmods.Crucible.addStoked(entrees[],
//  sorties[]) — fournie par ModTweaker, voir 06_forge.zs.
// =====================================================================

import mods.betterwithmods.Crucible;

val metaux = [
    "Iron", "Gold", "Copper", "Tin", "Silver", "Lead",
    "Aluminum", "Nickel", "Platinum", "Zinc"
] as string[];

for metal in metaux {
    val minerai = oreDict.get("ore" ~ metal);
    val lingot = oreDict.get("ingot" ~ metal);
    if (!minerai.empty && !lingot.empty) {
        Crucible.addStoked([minerai], [lingot.firstItem]);
    }
}
