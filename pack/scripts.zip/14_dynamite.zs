#modloaded betterwithmods

// =====================================================================
//  LA DYNAMITE DE BETTERWITHMODS
//
//  Le meme raisonnement que le TNT vanilla dans 02_anachronismes.zs : un
//  explosif qui rase un mur d'un coup n'a rien a faire sur un serveur ou
//  la protection d'un hotel de ville est cense couter un siege, pas une
//  meche. On la retire ici plutot que d'etendre 02_anachronismes.zs :
//  ce fichier-la n'a pas de garde #modloaded, et l'objet vient d'un mod
//  qui peut manquer du pack.
//
//  Deux objets, la mise en bandeau comprise (assets/betterwithmods/
//  recipes/items/dynamite.json et dynamite_bundle.json, lus dans le jar).
//
//  Apres modification : REDEMARRAGE COMPLET.
// =====================================================================

import crafttweaker.item.IItemStack;
import mods.jei.JEI;

val explosifs = [
    <betterwithmods:dynamite>,
    <betterwithmods:dynamite_bundle>
] as IItemStack[];

for objet in explosifs {
    JEI.removeAndHide(objet);
}
